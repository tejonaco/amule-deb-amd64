The windows README is still work in progress.

Please go to http://wiki.amule.org for info.
